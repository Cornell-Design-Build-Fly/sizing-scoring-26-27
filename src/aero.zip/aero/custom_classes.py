import aerosandbox as asb
from aerosandbox import OperatingPoint
from dataclasses import dataclass
import numpy as np

# The purpose of this file is to define custom classes for use in the aero module. There is essentially
# one class for each of the three aero analysis functions/files - cruise, stability, and aerodynamics.

# (I think AirplaneAnalysisResult should be defined here instead of in vlm.py to make it simple to find).

# @dataclass(frozen=True)
# class AirplaneAnalysisResult:
#     """Compact output for a whole-airplane aerodynamic analysis run."""

#     CL: float
#     CD: float
#     CY: float
#     Cl: float
#     Cm: float
#     Cn: float
#     L: float
#     D: float
#     Y: float
#     l_b: float
#     m_b: float
#     n_b: float
#     runtime_seconds: float
#     converged: bool = True
#     CDi: float | None = None
#     CDp: float | None = None
#     D_induced: float | None = None
#     D_profile: float | None = None

@dataclass(frozen=True)
class CruiseCondition:
    """Compact output for a whole-airplane cruise analysis run. Contains the "operating point," which contains
    the velocity, angle of attack, and other parameters at cruise (see spec in aerosandbox), as well as the
    throttle setting."""

    operating_point: OperatingPoint
    throttle: float


@dataclass(frozen=True)
class StabilityResult:
    """
    Compact output for a whole-airplane stability analysis run.

    Static stability:
        Cma < 0  -> longitudinally stable
        Cnb > 0  -> directionally stable
        Clb < 0  -> laterally stable (dihedral effect)
        static_margin > 0 -> CG is ahead of neutral point (stable)

    Dynamic modes:
        eigenvalue real part < 0 -> mode is damped (stable)
        damping_ratio > 0        -> mode decays over time
    """

    # --- Static stability ---
    Cma: float           # dCm/d_alpha [1/rad]
    Cnb: float           # dCn/d_beta  [1/rad]
    Clb: float           # dCl/d_beta  [1/rad]
    static_margin: float # (x_np - x_cg) / c_ref  [dimensionless]
    x_np: float          # neutral point x-location [m]

    # --- Dynamic modes (eigenvalues as complex numbers) ---
    # Longitudinal
    phugoid_eigenvalue: complex
    phugoid_damping_ratio: float
    short_period_eigenvalue: complex
    short_period_damping_ratio: float
    # Lateral
    roll_subsidence_eigenvalue: complex
    roll_subsidence_damping_ratio: float
    dutch_roll_eigenvalue: complex
    dutch_roll_damping_ratio: float
    spiral_eigenvalue: complex
    spiral_damping_ratio: float
