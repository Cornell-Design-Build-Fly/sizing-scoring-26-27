import aerosandbox as asb
from aerosandbox import MassProperties
from aerosandbox.dynamics.flight_dynamics.airplane import get_modes
import numpy as np

from src.aero.custom_classes import CruiseCondition, StabilityResult
from src.aero.vlm import AirplaneAnalysisResult
from src.vectors import ASBDesignVector, DesignVector


def stability_analysis(
        design_vector: DesignVector,
        cruise_condition: CruiseCondition,
        aero_result: AirplaneAnalysisResult,
        cg: tuple[float, float, float],
        inertia_matrix: np.ndarray,  # 3x3: [[Ixx,Ixy,Ixz],[Ixy,Iyy,Iyz],[Ixz,Iyz,Izz]]
        weight: float,               # [N]
) -> StabilityResult:
    """
    Perform stability analysis for a given design vector and cruise condition.

    Uses AeroSandbox's AeroBuildup solver to compute all stability derivatives via
    finite differencing (replicating what XFLR5 does), then feeds those into ASB's
    built-in get_modes() to compute dynamic mode eigenvalues.

    Args:
        design_vector:    The design vector representing the airplane configuration.
        cruise_condition: Cruise operating point + throttle from cruise_analysis.
        aero_result:      Aero forces/moments from aero_analysis (not used directly
                          here, but kept in interface for future cross-checks).
        cg:               Center of gravity (x, y, z) in meters, in geometry axes.
        inertia_matrix:   3x3 numpy array of inertia tensor components about the CG
                          [[Ixx, Ixy, Ixz], [Ixy, Iyy, Iyz], [Ixz, Iyz, Izz]] [kg·m²]
        weight:           Total aircraft weight [N].

    Returns:
        StabilityResult with static stability derivatives and dynamic mode eigenvalues.
    """

    # --- Step 1: Build airplane and operating point ---
    # Rebuild airplane from design vector. make_airplane() sets xyz_ref to the wing
    # quarter-chord, which is fine for forces — but stability moments must be taken
    # about the actual CG. We override xyz_ref in AeroBuildup below (it accepts a
    # separate xyz_ref argument that takes precedence over airplane.xyz_ref).
    asb_dv = ASBDesignVector.from_design_vector(design_vector)
    airplane = asb_dv.make_airplane()
    op_point = cruise_condition.operating_point

    # --- Step 2: Compute all stability derivatives in one AeroBuildup call ---
    # AeroBuildup is chosen here because:
    #   - It is the fastest solver (~0.025 s/case vs ~0.07 s for LiftingLine)
    #   - run_with_stability_derivatives() is natively supported
    #   - It includes fuselage contributions to pitching moment (critical for Cma)
    #   - VLM also supports this, but misses fuselage moment contributions
    #
    # run_with_stability_derivatives() works by running the base AeroBuildup case
    # once, then perturbing each variable (alpha, beta, p, q, r) by a small finite-
    # difference step and re-running, extracting d(CL,CD,CY,Cl,Cm,Cn)/d(each var).
    aero_with_derivs = asb.AeroBuildup(
        airplane=airplane,
        op_point=op_point,
        xyz_ref=list(cg),       # All moments computed about the actual CG
    ).run_with_stability_derivatives(
        alpha=True,             # -> CLa, Cma, x_np  (longitudinal static stability)
        beta=True,              # -> CYb, Clb, Cnb   (lateral/directional static stability)
        p=True,                 # -> Clp              (roll damping -> roll subsidence)
        q=True,                 # -> Cmq              (pitch damping -> short period)
        r=True,                 # -> Cnr, Clr, CYr   (yaw damping -> dutch roll, spiral)
    )

    # AeroBuildup returns 0-d numpy arrays; convert everything to plain floats so
    # downstream code (get_modes, StabilityResult) doesn't see unexpected array types.
    def _sc(key):
        return float(np.asarray(aero_with_derivs[key]).flat[0])

    # Patch the dict in-place so get_modes() also gets scalar values.
    for k in list(aero_with_derivs.keys()):
        v = aero_with_derivs[k]
        if hasattr(v, '__len__') or hasattr(v, 'flat'):
            try:
                aero_with_derivs[k] = float(np.asarray(v).flat[0])
            except (TypeError, ValueError):
                pass  # Leave non-numeric values (e.g. lists of component results) alone

    # --- Step 3: Extract static stability metrics ---
    Cma = _sc("Cma")          # < 0 = longitudinally stable
    Cnb = _sc("Cnb")          # > 0 = directionally stable
    Clb = _sc("Clb")          # < 0 = laterally stable
    x_np = _sc("x_np")        # neutral point x-location [m]
    static_margin = (x_np - cg[0]) / airplane.c_ref  # > 0 = CG ahead of NP = stable

    # --- Step 4: Build mass properties for dynamic mode calculation ---
    mass_props = MassProperties(
        mass=weight / 9.806,
        x_cg=cg[0],
        y_cg=cg[1],
        z_cg=cg[2],
        Ixx=float(inertia_matrix[0, 0]),
        Iyy=float(inertia_matrix[1, 1]),
        Izz=float(inertia_matrix[2, 2]),
        Ixy=float(inertia_matrix[0, 1]),
        Iyz=float(inertia_matrix[1, 2]),
        Ixz=float(inertia_matrix[0, 2]),
    )

    # --- Step 5: Compute dynamic modes ---
    # get_modes() uses simplified analytical approximations from Caughey's Cornell
    # flight dynamics textbook (FVA). These are approximate (not full 6-DOF eigenvalue
    # solve) but are sufficient for DBF-scale stability screening.
    modes = get_modes(
        airplane=airplane,
        op_point=op_point,
        mass_props=mass_props,
        aero=aero_with_derivs,
    )

    # --- Step 6: Package and return ---
    return StabilityResult(
        # Static
        Cma=Cma,
        Cnb=Cnb,
        Clb=Clb,
        static_margin=static_margin,
        x_np=x_np,
        # Longitudinal dynamic modes
        phugoid_eigenvalue=complex(
            modes["phugoid"]["eigenvalue_real"],
            modes["phugoid"]["eigenvalue_imag"],
        ),
        phugoid_damping_ratio=float(modes["phugoid"]["damping_ratio"]),
        short_period_eigenvalue=complex(
            modes["short_period"]["eigenvalue_real"],
            modes["short_period"]["eigenvalue_imag"],
        ),
        short_period_damping_ratio=float(modes["short_period"]["damping_ratio"]),
        # Lateral dynamic modes
        roll_subsidence_eigenvalue=complex(
            modes["roll_subsidence"]["eigenvalue_real"],
            0.0,
        ),
        roll_subsidence_damping_ratio=float(modes["roll_subsidence"]["damping_ratio"]),
        dutch_roll_eigenvalue=complex(
            modes["dutch_roll"]["eigenvalue_real"],
            modes["dutch_roll"]["eigenvalue_imag"],
        ),
        dutch_roll_damping_ratio=float(modes["dutch_roll"]["damping_ratio"]),
        spiral_eigenvalue=complex(
            modes["spiral"]["eigenvalue_real"],
            0.0,
        ),
        spiral_damping_ratio=float(modes["spiral"]["damping_ratio"]),
    )
